package com.example.android.apollotrivia;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    int score=0;
    int answer1=0;
    int answer2=0;
    int answer3=0;
    int answer4=0;
    String priceMessage = "Total: $";
    //String answerText1 = getString(R.string.answer_1);
    //String answerText2 = getString(R.string.answer_2);
    //String answerText3 = getString(R.string.answer_3);
    //String answerText4 = getString(R.string.answer_4);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }
    /**
     * This method is called when question 1 submit button is clicked.
    */
    public void displayAnswer1(View view) {
        TextView answerTextView = (TextView) findViewById(R.id.question1);
        ImageView answerImageView = (ImageView) findViewById(R.id.question1_image);
        RadioButton answer1RadioBtn = (RadioButton) findViewById(R.id.radio_button_3);
        answerTextView.setText(R.string.answer_1);
        answerImageView.setImageResource (R.drawable.michaelcollins);
        answer1RadioBtn.setChecked(true);
    }

    /**
     * This method creates a summary of the order.
     *
     * @param answerText1 is the answer for question 1
     */
    private String setAnswerText1(RadioButton radioButton3){
        if (radioButton3.isChecked()) {
            //answerText1="Correct! \n"+answerText1;
        }
        else {
            //answerText1="Sorry, that's not correct. \n"+answerText1;
        }

        return //answerText1;
    }


    /**
     * Calculates the answer for question 2 (the value of the correct answer is 7).
     *
     * @return this method returns the value of answer 2.
     */
    public int answer2(boolean cb1, boolean cb2, boolean cb3, boolean cb4) {
        int answer2 = 0;
        if (cb1) {
            answer2+=1;
        }
        if (cb2){
            answer2 +=2;
        }
        if (cb3){
            answer2 +=3;
        }
        if (cb4){
            answer2 +=4;
        }
        return answer2;
    }

    /**
     * This method is called when question 2 submit button is clicked.
     */
    public void displayAnswer2(View view) {
        CheckBox checkBox1 = (CheckBox) findViewById(R.id.checkbox1);
        Boolean cb1 =checkBox1.isChecked();
        CheckBox checkBox2 = (CheckBox) findViewById(R.id.checkbox2);
        Boolean cb2 =checkBox2.isChecked();
        CheckBox checkBox3 = (CheckBox) findViewById(R.id.checkbox3);
        Boolean cb3 =checkBox3.isChecked();
        CheckBox checkBox4 = (CheckBox) findViewById(R.id.checkbox4);
        Boolean cb4 =checkBox4.isChecked();

        TextView answerTextView = (TextView) findViewById(R.id.question2); // get the id for the text object for question 2
        ImageView answerImageView = (ImageView) findViewById(R.id.question2_image); // get the id for object image 2
        answerTextView.setText(R.string.answer_2); //change the string of the text object for question 2 to reveal the answer
        answerImageView.setImageResource (R.drawable.quarantine2); //change the image for object image 2
    }

    /**
     * This method is called when question 3 submit button is clicked.
     */
    public void displayAnswer3(View view) {
        TextView answerTextView = (TextView) findViewById(R.id.question3);
        ImageView answerImageView = (ImageView) findViewById(R.id.question3_image);
        answerTextView.setText(R.string.answer_3);
        answerImageView.setImageResource (R.drawable.apollo12crew);
    }

    /**
     * This method is called when question 4 submit button is clicked.
     */
    public void displayAnswer4(View view) {
        TextView answerTextView = (TextView) findViewById(R.id.question4);
        ImageView answerImageView = (ImageView) findViewById(R.id.question4_image);
        answerTextView.setText(R.string.answer_4);
        answerImageView.setImageResource (R.drawable.genecernan);
    }
}