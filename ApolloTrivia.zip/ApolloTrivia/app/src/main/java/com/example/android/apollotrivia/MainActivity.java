package com.example.android.apollotrivia;

import android.content.Context;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    int score = 0;
    int answer1 = 0;
    int answer2 = 0;
    int answer3 = 0;
    int answer4 = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    /**
     * This method is called when question 1 submit button is clicked.
     */
    public void displayAnswer1(View view) {
        if (answer1 > 0) {
            return;
        }
        String answer1Note = getString(R.string.answer_1);
        TextView answerTextView = (TextView) findViewById(R.id.question1);
        ImageView answerImageView = (ImageView) findViewById(R.id.question1_image);
        RadioButton answer1RadioBtn = (RadioButton) findViewById(R.id.radio_button_1);

        if (answer1 == 1) {
            answerTextView.setText(answer1Note);
            answer1RadioBtn.setChecked(true);
            return;
        }

        if (answer1RadioBtn.isChecked()) {
            answer1Note = "Correct! \n" + answer1Note;
            answerTextView.setText(answer1Note);
            answer1 = 1;
            score += 25;
        } else {
            answer1Note = "Sorry, that's not correct. \n" + answer1Note;
            answerTextView.setText(answer1Note);
            answer1 = 1;
        }

        answerImageView.setImageResource(R.drawable.michaelcollins);
        answer1RadioBtn.setTypeface(answer1RadioBtn.getTypeface(), Typeface.BOLD_ITALIC);
        answer1RadioBtn.setChecked(true);
    }

    /**
     * This method is called when question 2 submit button is clicked.
     */
    public void displayAnswer2(View view) {
        if (answer2 > 0) {
            return;
        }

        String answer2Note = getString(R.string.answer_2);
        TextView answerTextView = (TextView) findViewById(R.id.question2); // get the id for the text object for question 2
        ImageView answerImageView = (ImageView) findViewById(R.id.question2_image); // get the id for object image 2
        CheckBox checkBox1 = (CheckBox) findViewById(R.id.checkbox1);
        Boolean cb1 = checkBox1.isChecked();
        CheckBox checkBox2 = (CheckBox) findViewById(R.id.checkbox2);
        Boolean cb2 = checkBox2.isChecked();
        CheckBox checkBox3 = (CheckBox) findViewById(R.id.checkbox3);
        Boolean cb3 = checkBox3.isChecked();
        CheckBox checkBox4 = (CheckBox) findViewById(R.id.checkbox4);
        Boolean cb4 = checkBox4.isChecked();

        if (answer2 > 0) {
            answerTextView.setText(answer2Note);
            return;
        }
        if (cb1) {
            answer2 += 1;
        }
        if (cb2) {
            answer2 += 2;
        }
        if (cb3) {
            answer2 += 3;
        }
        if (cb4) {
            answer2 += 4;
        }
        if (answer2 == 7) {
            answer2Note = "Correct! \n" + answer2Note;
            answerTextView.setText(answer2Note);
            score += 25;
        } else {
            answer2Note = "Sorry, that's not correct. \n" + answer2Note;
            answer2 = 1;
            answerTextView.setText(answer2Note);
        }
        answerImageView.setImageResource(R.drawable.quarantine2);
        checkBox1.setTypeface(checkBox1.getTypeface(), Typeface.BOLD_ITALIC);
        checkBox1.setChecked(true);
        checkBox2.setTypeface(checkBox2.getTypeface(), Typeface.BOLD_ITALIC);
        checkBox2.setChecked(true);
        checkBox4.setTypeface(checkBox4.getTypeface(), Typeface.BOLD_ITALIC);
        checkBox4.setChecked(true);
        checkBox3.setChecked(false);
    }

    /**
     * This method is called when question 3 submit button is clicked.
     */
    public void displayAnswer3(View view) {
        if (answer3 > 0) {
            return;
        }
        String answer3Note = getString(R.string.answer_3);
        TextView answerTextView = (TextView) findViewById(R.id.question3);
        ImageView answerImageView = (ImageView) findViewById(R.id.question3_image);
        EditText answer3Entry = (EditText) findViewById(R.id.answer_3_Field);
        String answer3Number = answer3Entry.getText().toString();

        if (answer3Number.matches("")) {
            Toast.makeText(this, "Enter a number.", Toast.LENGTH_LONG).show();
            return;
        } else if (answer3Number.matches("3")) {
            answer3Note = "Correct! \n" + answer3Note;
            answerTextView.setText(answer3Note);
            answer3 = 1;
            score += 25;
            answer3Entry.clearFocus();
        } else {
            answer3Note = "Sorry, that's not correct. \n" + answer3Note;
            answerTextView.setText(answer3Note);
            answer3 = 1;
        }
        answerImageView.setImageResource(R.drawable.apollo12crew);
        answer3Entry.setText("3");
    }

    /**
     * This method is called when question 4 submit button is clicked.
     */
    public void displayAnswer4(View view) {
        if (answer4 > 0) {
            return;
        }

        String answer4Note = getString(R.string.answer_4);
        TextView answerTextView = (TextView) findViewById(R.id.question4);
        ImageView answerImageView = (ImageView) findViewById(R.id.question4_image);
        RadioButton answer4RadioBtn = (RadioButton) findViewById(R.id.radio_button_3);

        if (answer4 == 1) {
            answerTextView.setText(answer4Note);
            answer4RadioBtn.setChecked(true);
            return;
        }

        if (answer4RadioBtn.isChecked()) {
            answer4Note = "Correct! \n" + answer4Note;
            answerTextView.setText(answer4Note);
            answer4 = 1;
            score += 25;
        } else {
            answer4Note = "Sorry, that's not correct. \n" + answer4Note;
            answerTextView.setText(answer4Note);
            answer4 = 1;
        }
        answerImageView.setImageResource(R.drawable.genecernan);
        answer4RadioBtn.setTypeface(answer4RadioBtn.getTypeface(), Typeface.BOLD_ITALIC);
        answer4RadioBtn.setChecked(true);
    }

    /**
     * This method is called when the Get Score button is clicked.
     */
    public void getScore(View view) {
        EditText name = (EditText) findViewById(R.id.name_field);
        String nameField = name.getText().toString();
        Toast.makeText(this, nameField + ", your score is " + score + "!", Toast.LENGTH_LONG).show();
    }

    public void welcome(View view) {
        EditText name = (EditText) findViewById(R.id.name_field);
        String nameField = name.getText().toString();
        if (nameField.matches("")) {
            Toast.makeText(this, "Enter your name before you begin.", Toast.LENGTH_LONG).show();
            return;
        }
        InputMethodManager inputManager = (InputMethodManager)
                getSystemService(Context.INPUT_METHOD_SERVICE);

        inputManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(),
                InputMethodManager.HIDE_NOT_ALWAYS);
        name.clearFocus();
        Toast.makeText(this, "Hi, " + nameField + ", welcome to the Apollo Trivia app!", Toast.LENGTH_LONG).show();
    }

}